#include <iostream>
#include "ragnarstest.h"
#include "student1cstackl.h"

using namespace std;

int main(int , char **)
{
    cout << endl << "ListCStack" << endl;


    studentTest1();

    ragnarsTest1();

}
