#ifndef RAGNARSTEST_H
#define RAGNARSTEST_H



bool ragnarsTest1();


#endif // RAGNARSTEST_H
