
#include <iostream>
#include <iostream>

#include "student2stackl.h"
#include "ragnarstest2.h"

using namespace std;



int main(int argc, char *argv[])
{
    cout << endl << endl << "List Based CPP Stack" << endl;

    studentTest2();

    ragnarsTest2();


}
