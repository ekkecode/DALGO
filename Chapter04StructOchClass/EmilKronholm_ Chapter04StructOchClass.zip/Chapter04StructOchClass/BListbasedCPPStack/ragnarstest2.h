#ifndef RAGNARSTEST2_H
#define RAGNARSTEST2_H


bool ragnarsTest2();


#endif // RAGNARSTEST2_H
