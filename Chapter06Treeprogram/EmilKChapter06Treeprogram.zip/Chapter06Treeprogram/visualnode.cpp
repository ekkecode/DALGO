// Copyright (c) by Ragnar Nohre

#include "visualnode.h"
#include "treeviewwidget.h"

VisualNode::VisualNode()
{
}

VisualNode::~VisualNode(){
}

