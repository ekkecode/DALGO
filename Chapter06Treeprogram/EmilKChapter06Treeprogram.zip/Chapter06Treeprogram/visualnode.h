// Copyright (c) by Ragnar Nohre
#ifndef VISUALNODE_H
#define VISUALNODE_H

#include <QRect>

class VisualNode
{

public:
    VisualNode();
    virtual ~VisualNode();



};

#endif // VISUALNODE_H
