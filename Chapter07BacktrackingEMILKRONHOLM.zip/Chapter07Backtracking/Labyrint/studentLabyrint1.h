#ifndef STUDENT1_H
#define STUDENT1_H

#include "imaze.h"

bool didIndicatePathToGoal(IMaze *pMaze, int r, int k);

#endif // STUDENT1_H
