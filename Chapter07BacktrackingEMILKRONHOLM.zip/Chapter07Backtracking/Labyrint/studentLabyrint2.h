#ifndef STUDENT2_H
#define STUDENT2_H

#include "imaze.h"

bool foundShortestPathToGoalFIFO(IMaze *pMaze, int r, int k);


#endif // STUDENT2_H
