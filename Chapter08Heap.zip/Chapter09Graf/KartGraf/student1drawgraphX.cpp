#include "student1drawgraph.h"


const char* nameOfStudent1(){
    return  "cHomer Simpson";
}


void studentsDrawGraph(QPainter& painter,  const std::vector<Node>& graph){


   //TODO
}



