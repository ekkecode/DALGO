#ifndef RAGNARSTEST_H
#define RAGNARSTEST_H


void ragnarsTest(bool testHeapsort, bool testMergesort);


#endif // RAGNARSTEST_H
