#ifndef MERGESORT_H
#define MERGESORT_H

const char* nameOfStudentMergesort();

void mergesort(float* pBegin, float* pEnd);


#endif // MERGESORT_H
