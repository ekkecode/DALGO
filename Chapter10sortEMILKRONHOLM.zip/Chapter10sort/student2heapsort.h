#ifndef HEAPSORT_H
#define HEAPSORT_H

const char* nameOfStudentHeapsort();

void heapsort(float* pBegin, float* pEnd);

#endif // HEAPSORT_H
