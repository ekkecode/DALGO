#ifndef RAGNARSTEST_H
#define RAGNARSTEST_H
#include <string>

bool ragnarsTest();
std::string stringWithLastError();


#endif // RAGNARSTEST_H
