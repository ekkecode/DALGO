#ifndef RAGNARSTEST_H
#define RAGNARSTEST_H

#include <string>

bool ragnarsTest(bool testAQue, bool testLQue, bool testADeque);



#endif // RAGNARSTEST_H
