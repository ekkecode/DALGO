#ifndef RAGNARSTEST_H
#define RAGNARSTEST_H


#include <string>

bool ragnarsTest();

#endif // RAGNARSTEST_H
